# Security policy

This repository contains a **synthetic, local-only security research arena** with C00–C43 replay cases. It is not approved for use with production secrets, real customer records, arbitrary endpoints, or public network exposure.

Please disclose suspected vulnerabilities privately through the repository host's security advisory feature when available; otherwise contact the maintainers through a non-public channel listed on the future project page. Do not file an issue containing credentials or real exfiltration data. Maintainers have not yet published a support or patch SLA.

Avoid running third-party or unknown agent tools in the same host context as personal secrets. Run with least privilege and bind local services to loopback.

Private database receipts retain payload integrity digests. Ordinary API/SSE events expose bounded metadata and redacted lineage, excluding raw payloads, receiver keys and target-dependent payload digests. A database reader is outside the modeled actor boundary; a digest of a low-entropy value can enable offline guessing. This is a local synthetic arena, not a secrecy guarantee for production data. Raw model prompt/response capture is not enabled. Use only synthetic fixtures and keep the service bound to loopback.
