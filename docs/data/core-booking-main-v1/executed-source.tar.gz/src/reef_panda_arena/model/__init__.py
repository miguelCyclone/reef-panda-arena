"""Model and replay adapters."""
