"""Bounded run lifecycle."""
