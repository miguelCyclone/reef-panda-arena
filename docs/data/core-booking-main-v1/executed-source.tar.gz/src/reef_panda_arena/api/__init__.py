"""Thin local HTTP transport."""
