"""Validated scenario definitions."""
