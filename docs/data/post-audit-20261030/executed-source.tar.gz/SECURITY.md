# Security policy

This repository contains a **synthetic, local-only security research arena** with C00–C43 replay cases. It is not approved for use with production secrets, real customer records, arbitrary endpoints, or public network exposure.

Please disclose suspected vulnerabilities privately through the repository host's security advisory feature when available; otherwise contact the maintainers through a non-public channel listed on the future project page. Do not file an issue containing credentials or real exfiltration data. Maintainers have not yet published a support or patch SLA.

Avoid running third-party or unknown agent tools in the same host context as personal secrets. Run with least privilege and bind local services to loopback.

The event ledger and SSE API expose SHA-256 digests and metadata for synthetic payloads. A digest of a low-entropy value can enable offline guessing; these fields are not a secrecy boundary for real data. Use only the included synthetic fixtures and keep the service bound to loopback.
