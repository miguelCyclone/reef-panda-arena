# Post-audit verification and matched replay study

**Status: final study pending verification.** No final efficacy rate is asserted on this page yet. Historical results remain in their original reports and are not pooled with this study.

## Predeclared scope

The planned replay study covers the existing C00–C43 scenarios, seeds 31, 32 and 33, all six applicable policy profiles, and one attacked / one task-only control per combination: **1,584 planned trials in 792 pairs**. These are planned counts, not completed-run results. Runs use `key_derived_unknown`, local MySQL, local mock sinks, audit admission, bounded per-run budgets and sequential execution. No model is called by this replay study.

All families are affected by the corrected scoring, participant-knowledge and utility contracts. Case IDs are not independent discovered techniques: C29/C31/C43, C35/C42 and C32/C38 have explicit shared replay algorithms. C34's denied read, C37's internal-only attack path and C40's partial prefix require separate interpretation.

```bash
.venv/bin/python tools/benchmark_post_audit.py \
  --start 0 --end 43 --seeds 31 32 33 \
  --output .build/measurements/post-audit-new-study
```

The output directory must be new and ignored by Git. The runner preassigns every UUID and pair before execution, freezes the full public source tree, records the base commit/dirty state/dependencies/hardware, appends each trial to JSONL, checks for source changes, re-reads persisted reports, and writes CSV plus condition-specific aggregates. It never resets the database or overwrites historical studies. Completed results will link to their executed source identity; subsequent documentation changes do not change which implementation was measured.

## Interpretation contract

- An attempted action, accepted internal handoff, observer alert, policy block, accepted sink receipt, full recovery, partial recovery and useful task completion are distinct evidence.
- Full-recovery, strict-win and utility rates have their own measured eligible completed-run denominators. Failed runs remain visible, including any confirmed recovery before failure. Zero eligible trials means not measured.
- The observer is a local approximation with declared visibility; these are not vendor defender evaluations. A taint block establishes enforcement of tracked influence, not content decoding.
- Partial prefix/component recovery is separate from full recovery. Alphabet-model capacity is not measured source entropy or a proof that no other information escaped.
- Shape-matched legitimate-action false alerts and false blocks use actual inspection/decision denominators. Public transport probes do not replace task-only controls.

## Execution categories

| Category | Evidence boundary |
|---|---|
| `scripted_replay` | Fixed local workflows and attacks; the final matrix on this page will use this category |
| `instructed_live_copy` | Historical C00 local-model experiments, at their original revisions |
| `bounded_model_proposer` | C22–C28 data-only model proposals with separate task and gateway contracts; historical live tables remain separate |
| `independent_live_agents` | R06 actual Ollama requests, independently scoped role decisions and preserved failed trials; see [negative results and provenance](INDEPENDENT_ROLES.md) |
| `injected_policy_weakness` | Intentionally weak actor-local policy baseline; a deliberate lineage-drop experiment has not been implemented or measured |

The independent-role experiment is not a successful autonomous-leak or defense demonstration: all 24 starts failed, with no accepted private read or sink receipt. Its zero efficacy denominator is not a 0% leak rate. This negative evidence is kept under its own source/model/prompt versions rather than merged with replay.

## Historical evidence

[Earlier measurements](MEASUREMENTS.md), [adaptive results](ADAPTIVE_RESULTS_C22_C28.md), and [unified replay history](MEASUREMENTS_C29_C43.md) retain the old numbers and source identifiers. They are comparison records, not current validation. New data must not silently upgrade historical fixture proxies, safe-writer utility or incomplete runs into current scientific claims.
